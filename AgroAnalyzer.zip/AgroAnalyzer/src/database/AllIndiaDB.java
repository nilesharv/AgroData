package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.DatabaseMetaData;
public class AllIndiaDB {	
		static Connection con=null;
		static DatabaseMetaData meta;
		static String DatabaseName="AllIndia1.db";
		

			public static Statement getStatement() throws Exception
			{
				if(con==null)
				{
					try
					{
						Class.forName("org.sqlite.JDBC");
						con=DriverManager.getConnection("jdbc:sqlite:"+DatabaseName);
					
					}catch(Exception ex){
						
					}
				}
				
				return 	con.createStatement();
				
			}
			
			
 
			public static DatabaseMetaData getMetaData() throws Exception
			{
				if(con==null)
				{
					try
					{
						Class.forName("org.sqlite.JDBC");
						con=DriverManager.getConnection("jdbc:sqlite:"+DatabaseName);
					
					}catch(Exception ex)
					{
						
					}
				}
				
				return 	con.getMetaData();
				
			} 
			
			public static void Close()
			{
				try
				{
				con.close();
				}catch(Exception ex)
				{
					
				}
				con=null;
			}
		 
}
