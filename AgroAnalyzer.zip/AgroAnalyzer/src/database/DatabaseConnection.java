package database;

import java.sql.*;
public class DatabaseConnection {
	
	Connection con;
	Statement st;
		public DatabaseConnection(String databaseName) {
			
			try
			{
				Class.forName("org.sqlite.JDBC");
				con=DriverManager.getConnection("jdbc:sqlite:"+databaseName);
				st=con.createStatement();
			}catch(Exception ex){
				
			}
			
		}
	 
		public Statement getStatement()
		{
			return st;
		}
		
		
	 
	}

