Database
1.agrodata (ALL India)
2.statedata (State )

agrodata

create table [tableName] (year int,[nameOFCrops float]+,unit varchar(50));

statedata
create table [tablename] (year int,state varchar(50),[nameOFCrops float]+,unit varchar(50));



create table WOOL (year int,WOOL double,unit varchar(50));